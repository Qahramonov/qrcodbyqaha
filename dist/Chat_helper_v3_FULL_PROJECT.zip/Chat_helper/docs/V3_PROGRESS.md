# Chat helper v3.0 — журнал разработки

Исходное ТЗ: `Chat_helper_v3_MASTER_PROMPT.txt` (41 раздел). Работа идёт фазами; после каждой — тесты и коммит.

## Phase 1 — аудит (готово)

| Область | Что было в v1/v2 | Что требует v3 |
|---|---|---|
| Admin Panel | видна super_admin **и moderator** (бот: `screen_home`, API: `deps.admin`, APK: capability `users`) | только ID 8053614984 на всех уровнях |
| Доступ до подключения | все команды и меню доступны без Business-подключения | только /start, /help, /connect, проверка, инструкция, язык, поддержка (+ /app для привязки APK к мастеру подключения) |
| `.mute` | выключал автоответы в чате (`chats.muted_until`) | удалять новые входящие через `deleteBusinessMessages` (право `can_delete_all_messages`), подтверждение, таймер, типы, отчёт; старое поведение → `.quiet` |
| `.online` | честное объяснение NOT_SUPPORTED | сохранить честность; добавить «Chat Activity» только во время реальной обработки |
| `.a` | typewriter, 8 кадров, 0.9 с | Animation Engine: 16 типов, 4 скорости, отмена, без FloodWait |
| `.r` | chat action «печатает» | RTL-эффект; chat actions → `.mad` |
| `.info` (media) | сведения о файле | сведения о пользователе; файл → `.finfo` |
| Локализация | пары `tr(lang, ru, uz)` прямо в коде | JSON-каталоги ru/uz(/en) с ключами + тесты |
| Inline-кнопки в бизнес-чатах | не использовались | Chat Control Framework (control messages, owner-only callbacks, идемпотентность) |

### Проверенные факты Bot API (aiogram 3.31 = Bot API 10.3; core.telegram.org из среды недоступен)
* `editMessageText`: «business messages that were not sent by the bot and do not contain an inline keyboard can only be edited within 48 hours» → inline-клавиатуры в бизнес-сообщениях поддерживаются.
* `deleteBusinessMessages`: `can_delete_sent_messages` — сообщения бота, `can_delete_all_messages` — любые.
* `BusinessBotRights`: + `can_delete_outgoing_messages` (deprecated с 9.1).
* Ephemeral messages (`ephemeral_message_parameters`) — методы без `business_connection_id` → в бизнес-чатах не используем; приватный вариант = личка с ботом.
* Manage Bot bar → `/start bizChat<user_chat_id>` (Bot Features, grammY guide). Premium для подключения бизнес-бота не нужен.

## План фаз
- [x] 1. Аудит
- [x] 2–3. RBAC (только super admin), gating до подключения, онбординг + инфографика RU/UZ, `tg://settings/edit` — `handlers/ui.py`, `handlers/onboarding.py`, `media/infographic.py`, tests `test_v3_access.py`
- [x] 4–6. Chat Context Manager (`bizChat`), Chat Control Framework, Mute Engine, Protect/.g, .nogif, .nomute, карточки AFK/auto/online, `.sum`, инспектор прав — `services/chat_controls.py`, `modules/controls.py`, `modules/chat_filters.py`, `handlers/controls.py`, `handlers/chatmgr.py`, миграция M003, tests `test_v3_controls.py`
  - TODO позже: экспорт/удаление данных пользователя должны включать новые таблицы (Phase 12); `.re` (Phase 7) использует карточку `re`
- [x] 7–9. Animation Engine (`modules/animations.py`, 16 типов, 4 скорости, студия), `.re` (`modules/repeat.py`), `.r` RTL (`utils/unicode.py`), `.mad`, `.ball`, `.morse`, `.info`/`.finfo`, `.geo`, `.ptext` (tesseract/AI), `.qr` decode (zxing-cpp/zbarimg/AI), `.gif` из фото, `.wtm` видео/кружок, `.remind`/`.remindf` (`services/reminders.py`), `.ai` (+`.gpt`), AI Twin (`ai/twin.py`, `handlers/twin.py`, `.twin`), tests `test_v3_features.py`
- [x] 11–12. Локализация: JSON-каталоги `localization/locales/{ru,uz}.json` (~1700 ключей), в handlers нет захардкоженного русского; новые панели (user/admin), делегирование, миграция M003, API — tests `test_v3_localization.py` (каталоги совпадают, плейсхолдеры, нет кириллицы в uz, все ключи из кода существуют, все экраны/админ-разделы/команды рендерятся на узбекском)
- [x] Админ-раздел невидим для всех, кроме Super Admin (запрос владельца): нет кнопок, админ-команды не существуют для других (`.logs` → «Неизвестная команда», нет в `.help`/подсказках/каталоге/API `/commands`), поддельные `ax:`/`adm:`/`bc:` и FSM-состояния → тихий ответ «мёртвой кнопки», 43 админ-маршрута API → тот же `404`, что несуществующий адрес (без токена — одинаковый `401`), Swagger выключен по умолчанию (`API_DOCS_ENABLED`), все попытки — в аудит — tests `test_v3_admin_hidden.py`
- [x] 13–14. Flutter-приложение `flutter_app/` (40 экранов на реальном API, RU/UZ, Super Admin только по роли с сервера) + дизайн-система (`design/tokens.json`, [FIGMA_DESIGN.md](FIGMA_DESIGN.md), скриншоты). APK собран в GitHub Actions (run 41418763510: analyze + test + build — success)
- [x] 15–16. Тесты (backend 238, Flutter 34, нативное v1 против v3 — 10), документация (15 файлов: README_RU/UZ, INSTALL_TERMUX, BUILD_FLUTTER, TELEGRAM_BUSINESS, COMMANDS, CHAT_CONTROLS, PERMISSIONS, LOCALIZATION, ADMIN_SECURITY, MIGRATION_V1_TO_V3, FEATURE_MATRIX, TEST_REPORT, API, FIGMA_DESIGN), `dist/Chat_helper_v3_FULL_PROJECT.zip`, отчёт
